/**
 *  Trabalho2
 * @author Obenson Maurice
 * @version 
 * @date Dez 2023
 * 
 * @copyright Copyright (c) 2023
 *
 *  
  * atenção: antes de entregar, conferir se dos dados acima da documentação estão
 * preenchidos corretamente.
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void copia(long long int *a, long long int *v, long long int size);

void troca(long long int *a, long long int *b);

void bubbleSort(long long int *a, long long int size, FILE *fptr);

void selectionSort(long long int *a, long long int size, FILE *fptr);

void insertionSort(long long int *a, long long int sizev, FILE *fptr);

void quickSort(long long int *a, long long int inicio, long long int fim, long long int *trocas);
long long int particiona(long long int *a, long long int inicio, long long int fim, long long int *trocas);

void heap(long long int *v, long long int n, FILE *fptr);
void criaheap(long long int *v, long long int n, long long int i, long long int *trocas);

void radiz(long long int *v, long long int n, FILE *fptr);
void couting(long long int *v, long long int n, long long int pos);
long long int buscamax(long long int *v, long long int n);

// 100,1000,5000,10000,50000,10000 esses dados para o teste 
int main(){
	long long int i, n = 100, trocas = 0;
    
	long long int *vetor = (long long int *)malloc(n * sizeof(long long int));
    for (int i=0; i< n; i++) vetor[i]=(rand()%(n + 1));  
    
   //FILE *fpte = fopen("tempot2.csv", "w"), *fptr = fopen("trocat2.csv", "w");  
   //fputs("Dados,Bubble,Selection,Insertion,Quick,Heap,Radix\n", fpte);
   //fputs("Dados,Bubble,Selection,Insertion,Quick,Heap,Radix\n", fptr); 
    
    FILE *fpte = fopen("tempot2.csv", "a"), *fptr = fopen("trocat2.csv", "a");
   
    fprintf(fpte, "%lld,", n);
    fprintf(fptr, "%lld,", n);
	//bubble sort

	long long int *bubbleVec = (long long int *)malloc(n * sizeof(long long int));
	copia(vetor, bubbleVec, n);

	clock_t begin = clock();
	bubbleSort(bubbleVec, n, fptr);
	clock_t end = clock();
	double time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	fprintf(fpte, "%lf,", time_spent);
	free(bubbleVec);

	//selection sort methode
	
	long long int *selectionVec = (long long int *)malloc(n * sizeof(long long int));
    copia(vetor, selectionVec, n);    
    begin = clock();
    selectionSort(selectionVec, n, fptr);
    end = clock();// fin du temps
    time_spent = (double)(end - begin) / CLOCKS_PER_SEC;// temps utilisé
    fprintf(fpte, "%lf,", time_spent);	
	free(selectionVec);

	//Insertion sort
	
	long long int *insetionVec = (long long int *)malloc(n * sizeof(long long int));
	copia(vetor, insetionVec, n);
	
	begin = clock();
	insertionSort(insetionVec, n, fptr);
	end = clock();
	time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
	fprintf(fpte, "%lf,", time_spent);
	
	free(insetionVec);
	//quick sort
	
	long long int *quickVec = (long long int *)malloc(n * sizeof(long long int));
	copia(vetor, quickVec, n);
    begin = clock();  
	quickSort(quickVec, 0, n - 1, &trocas);
	fprintf(fptr, "%lld,", trocas);
	end = clock();
    time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
    fprintf(fpte, "%lf,", time_spent);
	free(quickVec);
	//heap sort
	
	long long int *heapVec = (long long int *)malloc(n * sizeof(long long int));
	copia(vetor, heapVec, n);
    begin = clock();  
	heap(heapVec, n, fptr);
	end = clock();
    time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
    fprintf(fpte, "%lf,", time_spent);
	free(heapVec);

	//radix sort
    begin = clock();  
	radiz(vetor, n, fptr);
	end = clock();
    time_spent = (double)(end - begin) / CLOCKS_PER_SEC;
    fprintf(fpte, "%lf\n", time_spent);	
    fclose(fpte);
    fclose(fptr);
	free(vetor);
	return 0;
}

void copia(long long int *a, long long int *V, long long int size){
	for (int i = 0 ; i < size ; i++)
    	     V[i] = a[i];
}

void bubbleSort(long long int *a, long long int size, FILE *fptr){
    long long int count = 0;

    for (long long int i = 0; i < size - 1; i++) 
        for (long long int j = 0; j < size - i - 1; j++) {
            if (a[j] > a[j + 1]) {
                troca(&(a[j]), &a[j + 1]);
                count++;
            }}

   fprintf(fptr, "%lld,", count);
}

void selectionSort(long long int *a, long long int size, FILE *fptr){
    long long int count = 0;
    for (long long int i = 0; i < size - 1; i++) {
        long long int min = i;
        for (long long int j = i + 1; j < size; j++) {
            if (a[j] < a[min]) {
                min = j;
        }
    }

        if (min != i) {
            troca(&(a[i]), &(a[min]));
            count++;
    }
}
    fprintf(fptr, "%lld,", count);
}
        
void insertionSort(long long int *a, long long int size, FILE *fptr){
    long long int j, min;
    long long int count=0;
    for (long long int i = 1; i < size; i++) {   
        min = a[i];
        for (j = i; j > 0 && min < a[j-1]; j--){
            a[j]=a[j-1];
            count++;
        }   
        a[j]=min;
		count++;
    }
    fprintf(fptr, "%lld,", count);
}

void quickSort(long long int *a, long long int inicio, long long int fim,long long int *trocas){
	if ((inicio < fim)){
		long long int posPivo = particiona(a, inicio, fim, trocas);
		quickSort(a, inicio, posPivo - 1, trocas);
		quickSort(a, posPivo + 1, fim, trocas);
	}
}

long long int particiona(long long int *a, long long int inicio, long long int fim, long long int *trocas){
	long long int posPivo = (rand()%(fim - inicio + 1)) + inicio;
	long long int k = inicio;
	
	troca(&(a[posPivo]), &(a[fim]));
    (*trocas)++;
	
	for (long long int i = inicio; i < fim; i++){
		if (a[i] <= a[fim]){
			troca(&(a[k]), &(a[i]));
			k++;
			(*trocas)++;
		}}
	
	if (a[k] > a[fim]){
	    troca(&(a[k]), &(a[fim]));
	    (*trocas)++;
	}
	    
	return k;
}

void heap(long long int *v, long long int n, FILE *fptr){
	long long int trocas = 0;
    // fase 1
    for(long long int i = n/2 - 1; i >= 0; i--) criaheap(v, n, i, &trocas);

    // fase 2;
    for(long long int i = n - 1; i > 0; i--){
        troca(&(v[i]), &v[0]);
		trocas++;
        criaheap(v, i, 0, &trocas);
    }

	fprintf(fptr, "%lld,", trocas);
}

void criaheap(long long int *v, long long int n, long long int i,  long long int *trocas){
    int maior = i, left = 2 * i + 1, right = 2 * i + 2;

    if(left < n && v[maior] < v[left]) maior = left;
    if(right < n && v[maior] < v[right]) maior = right;

    if((maior != i)){
        troca(&(v[i]), &v[maior]);
		(*trocas)++;
        criaheap(v, n, maior, trocas);
		}
}

void radiz(long long int *v, long long int n, FILE *fptr){
    long long int count=0;
    long long int max = buscamax(v,n);
    for(long long int pos = 1; max / pos > 0; pos *= 10){
       couting(v, n, pos); 
       count += n;
    }
    fprintf(fptr,"%lld\n", count);
}

long long int buscamax(long long int *v, long long int n){
    long long int max = v[0];
    for(long long int i = 1; i < n; i++)
        if(max < v[i]) max = v[i];
    
    return max;
}

void couting(long long int *v, long long int n, long long int pos){
    long long int *aux = (long long int*)malloc(n * sizeof(long long int)),
        count[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    long long int i, digito;
    for(i = 0; i < n; i++){
        digito = (v[i] / pos) % 10;
        count[digito]++;
    }
    for(i = 1; i < 10; i++) count[i] = count[i] + count[i-1];
    for(i = n - 1; i >= 0; i--){
        digito = (v[i] / pos) % 10;
        count[digito] --;
        aux[count[digito]] = v[i];
    }

    for(i = 0; i < n; i++) v[i] = aux[i];
    free(aux);
}

void troca(long long int *a, long long int *b){
	long long int temp=*(b);
	*b=*a;
	*a=temp;
}
